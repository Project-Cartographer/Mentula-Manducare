Mentula 2.0.1
*THIS IS FOR LIVE LIST ONLY!!! Mentula does not support Network/LAN at this time.

1. Open port 9922 TCP on your router and Firewall inbound and outbound
*Example: https://www.windowscentral.com/how-open-port-windows-firewall

2. Then start the mentula_manducare.exe program (may run as admin)

3. To add a user, go to the command window and type: adduser NAME PASSWORD
*Example: adduser Bannana bannanapass1 (to remove a user just type: removeuser NAME)

4. To login and control the server(s) go to http://www.halo2pc.com/mentula and enter the server machine's IP with :9922 at the end
*Example: 218.3.158.12:9922

5. Then enter the password, click connect and you're in!
This tool has an updater built in now, so if an update goes out, it will just restart and download the latest version.

Source code: https://github.com/Kantanomo/mentula_manducare

Report issues to me on Discord! UncutFighter #1262
Halo 2 PC Discord: https://www.discord.gg/NZPYWbK


http://www.halo2pc.com/