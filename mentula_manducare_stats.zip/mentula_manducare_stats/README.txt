To point the stats to your servers edit "Scripts/stats.js" and go to line 5
Change the IP to your servers ip, and save the file.

Now when you open Stats.html it will pull the stats from your server.

Only basic styling has been added, anything else you will have to do yourself.